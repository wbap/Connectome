
NOTE:
  The tests in this folder write image files into this
  directory for visual inspection.
