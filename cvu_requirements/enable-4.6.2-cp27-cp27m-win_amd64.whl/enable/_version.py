# THIS FILE IS GENERATED FROM ENABLE SETUP.PY
version = '4.6.2'
full_version = '4.6.2'
git_revision = '7edd909'
is_released = True

if not is_released:
    version = full_version
