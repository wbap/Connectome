#  Copyright (c) 2005-2014 by Enthought, Inc.
#  All rights reserved.
""" Two-dimensional plotting application toolkit.
    Part of the Chaco project of the Enthought Tool Suite.
"""
from ._version import full_version as __version__  # noqa

__requires__ = [
   'enable',
]
