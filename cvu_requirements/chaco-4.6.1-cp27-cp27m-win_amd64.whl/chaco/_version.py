# This file was automatically generated from the `setup.py` script.
version = '4.6.1'
full_version = '4.6.1'
git_revision = '8609c29'
is_released = True

if not is_released:
    version = full_version
